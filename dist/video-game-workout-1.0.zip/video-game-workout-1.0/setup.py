from setuptools import setup

setup(
	name= 'video-game-workout',
	version='1.0',
	description='Generate workouts based on gameplay',
	author = 'Ryan Contino',
	author_email='RyanJ.Contino@gmail.com',
	url='ContinoTime.com',
	py_modules='videogameworkout',
	)